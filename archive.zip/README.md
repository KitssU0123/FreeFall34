第一次參加Game Jam，獨自一人開發。

從主題圖中的3和4，聯想到 Free與Fall，合起來是自由落體的意思。再加上1和2，合起來就是run to three floors，由此創作出此小遊戲。

素材使用：
Brackeys' Platformer Bundle
Free Trippy Animated Backgrounds
Cat Pixel Mega Pack
【フリーBGM】もじもじ【かわいい】
